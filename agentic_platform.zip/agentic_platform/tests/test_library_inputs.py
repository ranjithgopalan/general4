"""Uploaded inputs kept in the artefact store and synced back to the (ephemeral) local corpus.

    set PYTHONPATH=.
    python -m pytest app/agentic_platform/tests/test_library_inputs.py -q
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from app.agentic_platform.fe_core.artifacts.store import LocalArtifactStore
from app.agentic_platform.fe_core.kb import library_inputs as li

SAMPLE = Path(__file__).resolve().parents[3] / "doc" / "RED-Company-Search.json"
pytestmark = pytest.mark.skipif(not SAMPLE.is_file(), reason="sample RED JSON not present")


@pytest.fixture
def env(tmp_path):
    store = LocalArtifactStore(tmp_path / "bucket")
    roots = {}
    settings = SimpleNamespace(fe_s3_prefix="fe", corpus_root_for=lambda app_id: roots.setdefault(app_id, tmp_path / "ws" / app_id / "corpus"))
    return store, settings, settings.corpus_root_for("_library")


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def test_prefix_follows_the_build_key_layout_per_application(env):
    store, settings, _ = env
    assert li.inputs_prefix(store, settings) == "fe/_library/_global/inputs"
    assert li.inputs_prefix(store, settings, "asp-dep-demo") == "fe/asp-dep-demo/_global/inputs"
    assert li.index_key(store, settings).endswith("/inputs/index.json")
    assert li.read_index(store, settings) == {"modules": {}, "screens": {}, "files": {}, "updated_at": None}


def test_module_upload_goes_to_the_store_and_comes_back_on_sync(env):
    store, settings, corpus = env
    src = corpus / "re-cards" / "uwcr-credit-company-administration.json"
    src.parent.mkdir(parents=True)
    src.write_bytes(SAMPLE.read_bytes())
    r = li.put_module(store, settings, module_key="uwcr-credit-company-administration", path=src, gear_id="1429",
                      uploaded_by="me", module="UWCR", pages=12)
    assert r["ok"] and r["store"] == "local" and r["key"] == "fe/_library/_global/inputs/re-cards/uwcr-credit-company-administration.json"
    assert store.exists(r["key"]) and store.exists(li.index_key(store, settings))
    idx = li.read_index(store, settings)
    assert idx["modules"]["uwcr-credit-company-administration"]["sha256"] == _sha(src)
    assert idx["modules"]["uwcr-credit-company-administration"]["gear_id"] == "1429"

    # a fresh container: empty corpus, sync restores the file byte for byte
    fresh = corpus.parent / "fresh"
    out = li.sync_to_local(store, settings, fresh, adopt=False)
    assert out["ok"] and out["downloaded"] == ["re-cards/uwcr-credit-company-administration.json"]
    assert _sha(fresh / "re-cards" / "uwcr-credit-company-administration.json") == _sha(src)
    again = li.sync_to_local(store, settings, fresh, adopt=False)
    assert again["downloaded"] == [] and again["up_to_date"] == 1 and again["modules"] == 1


def test_keep_upload_uses_the_handler_reply(env):
    store, settings, corpus = env
    (corpus / "re-cards").mkdir(parents=True)
    (corpus / "re-cards" / "m1.json").write_bytes(SAMPLE.read_bytes())
    reply = {"module_key": "m1", "module": "M1", "pages": 12, "stored": {"file": "m1.json", "replaced": []}}
    r = li.keep_upload(store, settings, app_id="_library", document_kind="re-cards", reply=reply, gear_id="1429", uploaded_by="me")
    assert r["ok"] and r["key"].endswith("/re-cards/m1.json")
    assert li.keep_upload(store, settings, app_id="_library", document_kind="requirements", reply={})["ok"] is False


def test_replaced_module_file_leaves_the_index(env):
    store, settings, corpus = env
    d = corpus / "re-cards"
    d.mkdir(parents=True)
    old = d / "old-name.json"
    old.write_bytes(SAMPLE.read_bytes())
    li.put_module(store, settings, module_key="m1", path=old)
    new = d / "m1.json"
    new.write_bytes(SAMPLE.read_bytes())
    li.put_module(store, settings, module_key="m1", path=new, replaced=[str(old)])
    idx = li.read_index(store, settings)
    assert list(idx["modules"]) == ["m1"] and idx["modules"]["m1"]["file"] == "m1.json"


def test_screens_catalogue_and_pictures_round_trip(env):
    store, settings, corpus = env
    screens = corpus / "screens"
    (screens / "v1").mkdir(parents=True)
    (screens / "v1" / "img1.png").write_bytes(b"\x89PNG fake")
    (screens / "catalog-v1.json").write_text(json.dumps({"version": 1, "source_filename": "Screens.docx",
                                                        "source_sha256": "abc", "screens": []}), encoding="utf-8")
    r = li.put_screens(store, settings, version=1, screens_root=screens, gear_id="1429")
    assert r["ok"] and r["files"] == 2
    assert li.read_index(store, settings)["screens"]["1"]["source_filename"] == "Screens.docx"
    fresh = corpus.parent / "fresh"
    out = li.sync_to_local(store, settings, fresh, adopt=False)
    assert out["screens"] == 1 and sorted(out["downloaded"]) == ["screens/catalog-v1.json", "screens/v1/img1.png"]
    assert (fresh / "screens" / "v1" / "img1.png").read_bytes() == b"\x89PNG fake"


def test_project_asp_files_round_trip_under_the_project_prefix(env):
    store, settings, _ = env
    corpus = settings.corpus_root_for("asp-dep-demo")
    asp = corpus / "asp-source"
    asp.mkdir(parents=True)
    (asp / "CompanyDetail.asp").write_bytes(b"<% ' detail %>")
    (asp / "CompanySelect.asp").write_bytes(b"<% ' select %>")
    r = li.put_files(store, settings, kind="asp-source", paths=sorted(asp.iterdir()), app_id="asp-dep-demo", uploaded_by="me")
    assert r["ok"] and r["files"] == 2 and r["key"] == "fe/asp-dep-demo/_global/inputs/asp-source"
    assert set(li.read_index(store, settings, "asp-dep-demo")["files"]["asp-source"]) == {"CompanyDetail.asp", "CompanySelect.asp"}
    # the library's index is untouched
    assert li.read_index(store, settings)["files"] == {}
    # fresh container for the project
    fresh = corpus.parent / "fresh"
    out = li.sync_to_local(store, settings, fresh, app_id="asp-dep-demo", adopt=False)
    assert out["files"] == 2 and sorted(out["downloaded"]) == ["asp-source/CompanyDetail.asp", "asp-source/CompanySelect.asp"]
    assert (fresh / "asp-source" / "CompanySelect.asp").read_bytes() == b"<% ' select %>"
    assert li.storage_info(store, settings, app_id="asp-dep-demo")["files"] == 2


def test_files_already_on_disk_are_adopted_into_the_store(env):
    store, settings, corpus = env
    (corpus / "re-cards").mkdir(parents=True)
    (corpus / "re-cards" / "uwcr-credit-company-administration.json").write_bytes(SAMPLE.read_bytes())
    (corpus / "requirements").mkdir()
    (corpus / "requirements" / "brd.docx").write_bytes(b"PK fake docx")
    out = li.sync_to_local(store, settings, corpus)          # default adopt=True
    assert sorted(out["adopted"]) == ["re-cards/uwcr-credit-company-administration.json", "requirements/brd.docx"]
    idx = li.read_index(store, settings)
    assert idx["modules"]["uwcr-credit-company-administration"]["uploaded_by"] == "adopted-from-disk"
    assert idx["files"]["requirements"]["brd.docx"]["size"] == len(b"PK fake docx")
    info = li.storage_info(store, settings)
    assert info["modules"] == 1 and info["files"] == 1 and info["store"] == "local" and info["uri"].startswith("file:")


def test_sync_never_raises_on_a_broken_store(env):
    _store, settings, corpus = env

    class Broken:
        kind = "s3"

        def uri(self, key):
            return f"s3://bucket/{key}"

        def exists(self, key):
            raise RuntimeError("no credentials")

    out = li.sync_to_local(Broken(), settings, corpus, adopt=False)
    assert out["ok"] is True and out["modules"] == 0   # unreadable index reads as empty; nothing to do
