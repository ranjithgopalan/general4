"""Page dependency graph derived from a module JSON (the Global Library's re-cards upload).

    set PYTHONPATH=.
    python -m pytest app/agentic_platform/tests/test_module_graph.py -q
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.agentic_platform.fe_core.kb.cards_schema import normalise
from app.agentic_platform.fe_core.red_graph import module_graph
from app.agentic_platform.fe_core.red_graph.derive import REL_CALLS

SAMPLE = Path(__file__).resolve().parents[3] / "doc" / "RED-Company-Search.json"
pytestmark = pytest.mark.skipif(not SAMPLE.is_file(), reason="sample RED JSON not present")


@pytest.fixture(scope="module")
def graph():
    doc, violations, _ = normalise(json.loads(SAMPLE.read_text(encoding="utf-8-sig")))
    assert not violations
    g, info = module_graph.derive_from_module_docs([doc])
    return g, info


def _names(g, e):
    return g.nodes[e.source_key].name, g.nodes[e.target_key].name


def test_every_page_of_the_module_is_a_node_with_library_module_submodule_and_domain(graph):
    g, info = graph
    assert len(g.nodes) == 12 and info["modules"] == ["uwcr-credit-company-administration"]
    menu = next(n for n in g.nodes.values() if n.name == "CreditRiskDBMenu")
    assert menu.module == "UWCR - Credit Company Administration"          # the module JSON's module, not a folder
    assert menu.record.submodule == "AdminMenuRenderer"
    assert menu.record.business_domain == "Credit Risk Administration"
    assert menu.path == "/aiucredit/Credit/CreditRiskDBMenu.asp"
    assert "tblSystemAdmin" in menu.record.database_tables                 # from the shared ENT card's page list


def test_form_targets_and_callers_become_stated_calls_edges(graph):
    g, _ = graph
    stated = {_names(g, e) for e in g.edges if e.rel_type == REL_CALLS and e.confidence >= 0.9}
    assert ("AdminCompanySearch", "CompanySelect") in stated                # services_and_apis target
    assert ("AdminCompanySearch", "AdminCompanySearchResult") in stated    # keyword search posts there
    assert any(src == "CompanySelect" and dst == "CompanyDetail" for src, dst in stated)


def test_pages_named_only_in_prose_are_inferred(graph):
    g, _ = graph
    inferred = [e for e in g.edges if e.confidence <= 0.5]
    assert inferred and all(e.ambiguous for e in inferred)
    assert all(e.rel_type == REL_CALLS for e in inferred)


def test_no_self_references_and_summary_counts(graph):
    g, _ = graph
    assert all(e.source_key != e.target_key for e in g.edges)
    s = g.summary()
    assert s["nodes"] == 12 and s["edges"] == len(g.edges) > 10 and s["modules"] == 1


def test_corpus_loader_merges_every_module_json(tmp_path):
    corpus = tmp_path / "re-cards"
    corpus.mkdir()
    (corpus / "a.json").write_bytes(SAMPLE.read_bytes())
    g, info = module_graph.derive_from_corpus(corpus)
    assert info["files"] == ["a.json"] and len(g.nodes) == 12
    empty, info2 = module_graph.derive_from_corpus(tmp_path / "missing")
    assert not empty.nodes and info2["files"] == []
