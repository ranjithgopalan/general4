"""Page dependency graph derived from the Global Library's module JSONs (the re-cards uploads).

The client has the module JSON (one per module: pages with BR / FR / services-and-APIs / entities /
screens / workflows) but not the per-file RED analysis, so the page references are read from the
module JSON itself:

    services_and_apis[].target          this page posts to / navigates to that page   -> CALLS (stated)
    services_and_apis[].name            "Form POST to X.asp"                           -> CALLS (stated)
    services_and_apis[].callers         pages that call this one                       -> CALLS from them (stated)
    rule / requirement / service prose  pages named in text                            -> CALLS (inferred)
    data_entities (shared ENT cards)    tables a page uses, incl. entities whose `pages` list names it
                                                                                       -> REFERENCES to Table nodes

Module (category) = the module JSON's module, sub-module = ``business_domain.module``, domain =
``business_domain.domain``; the folder comes from ``source_path``. Works on the normalised cards
docs, so an upload in either RED JSON or cards JSON layout gives the same graph. Every field that
is not explicitly mapped by the cards conversion travels with the card unchanged (``_carry``), which
is why ``target`` and ``callers`` are still there.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Iterable

from app.agentic_platform.fe_core.kb.cards_schema import merge_modules, normalise, normalise_page
from app.agentic_platform.fe_core.red_graph.derive import DerivedGraph, FileRecord, derive

logger = logging.getLogger(__name__)

_PAGE_KINDS = ("CMP", "API")


def _s(v: Any) -> str:
    return str(v).strip() if v is not None and not isinstance(v, (list, dict)) else ""


def _texts(v: Any) -> list[str]:
    if v is None:
        return []
    if isinstance(v, str):
        return [v] if v.strip() else []
    if isinstance(v, list):
        return [t for x in v for t in _texts(x)]
    if isinstance(v, dict):
        return [t for x in v.values() for t in _texts(x)]
    return [str(v)]


def _int(v: Any) -> int:
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return 0


def _table_name(ent: dict | None) -> str:
    if not ent:
        return ""
    t = _s(ent.get("maps_to_table")) or _s(ent.get("label"))
    return t.rsplit(".", 1)[-1] if t else ""


def load_module_docs(corpus_dir: Path) -> list[tuple[Path, dict]]:
    """(file, normalised cards doc) for every readable module JSON in the library corpus."""
    out: list[tuple[Path, dict]] = []
    if not corpus_dir.is_dir():
        return out
    for path in sorted(corpus_dir.glob("*.json")):
        try:
            doc, violations, _notes = normalise(json.loads(path.read_text(encoding="utf-8-sig")))
        except Exception as exc:  # noqa: BLE001
            logger.warning("module_graph: %s skipped (%s)", path.name, exc)
            continue
        if violations:
            logger.warning("module_graph: %s skipped (%d validation issue(s))", path.name, len(violations))
            continue
        out.append((path, doc))
    return out


def records_from_merged(merged: dict) -> list[FileRecord]:
    """One FileRecord per page of a merged (or single) cards doc."""
    module_names = {m.get("module_key"): m.get("module") for m in merged.get("modules", []) if m.get("module_key")}
    default_key = merged.get("module_key") or ""
    default_name = merged.get("module") or ""

    shared_ent: dict[str, dict] = {}
    for card in merged.get("shared_cards", {}).get("ENT", []):
        if card.get("id"):
            shared_ent[card["id"]] = card
    # tables per page from the shared entities' own page lists
    tables_by_page: dict[str, set[str]] = {}
    for ent in shared_ent.values():
        t = _table_name(ent)
        if not t:
            continue
        for pg in ent.get("pages", []) or []:
            tables_by_page.setdefault(normalise_page(pg), set()).add(t)

    records: list[FileRecord] = []
    for page in merged.get("pages", []):
        name = _s(page.get("page"))
        if not name:
            continue
        norm = normalise_page(name)
        cards = page.get("cards", {}) or {}
        domain = page.get("business_domain") if isinstance(page.get("business_domain"), dict) else {}
        module_key = page.get("module_key") or default_key
        calls_out: list[str] = []
        triggers: list[str] = []
        mentions: list[str] = []
        tables = set(tables_by_page.get(norm, set()))
        for kind in _PAGE_KINDS:
            for card in cards.get(kind, []):
                for key in ("target", "name", "label", "component"):
                    v = _s(card.get(key))
                    if v and ".asp" in v.lower():
                        calls_out.append(v)
                triggers.extend(_texts(card.get("callers")))
                mentions.extend(_texts(card.get("function")) + _texts(card.get("description")) + _texts(card.get("business_function")))
        for card in cards.get("BR", []):
            mentions.extend(_texts(card.get("logic")) + _texts(card.get("description")) + _texts(card.get("acceptance_criteria")))
        for card in cards.get("FR", []):
            mentions.extend(_texts(card.get("description")) + _texts(card.get("verification")))
        for card in cards.get("SCR", []):
            mentions.extend(_texts(card.get("buttons")))
        for card in cards.get("ENT", []):
            ent = shared_ent.get(card.get("ref") or card.get("id") or "")
            t = _table_name(ent) or _table_name(card)
            if t:
                tables.add(t)
        records.append(FileRecord(
            file_name=name,
            file_path=_s(page.get("source_path")) or name,
            layer=_s(page.get("layer")) or None,
            risk_level=_s(page.get("risk_level")) or None,
            loc=_int(page.get("loc")),
            cyclomatic_complexity=_int(page.get("cyclomatic_complexity")),
            business_domain=_s(domain.get("domain")) or None,
            purpose=_s(domain.get("description")),
            business_rule_count=len(cards.get("BR", [])),
            database_tables=sorted(tables),
            calls_out=calls_out,
            triggers=triggers,
            mentions=mentions,
            module_name=module_names.get(module_key) or default_name or module_key or None,
            submodule=_s(domain.get("module")) or None,
        ))
    return records


def derive_from_module_docs(docs: Iterable[dict]) -> tuple[DerivedGraph, dict[str, Any]]:
    """Merge the module docs (one flat library namespace) and derive the page graph."""
    docs = list(docs)
    merged, clashes, _notes = merge_modules(docs)
    graph = derive(records_from_merged(merged))
    info = {"modules": [m.get("module_key") for m in merged.get("modules", [])] or [merged.get("module_key")],
            "module_clashes": len(clashes)}
    return graph, info


def derive_from_corpus(corpus_dir: Path) -> tuple[DerivedGraph, dict[str, Any]]:
    """The graph of every module JSON currently uploaded to the library."""
    loaded = load_module_docs(Path(corpus_dir))
    if not loaded:
        return derive([]), {"modules": [], "module_clashes": 0, "files": []}
    graph, info = derive_from_module_docs(doc for _, doc in loaded)
    info["files"] = [p.name for p, _ in loaded]
    return graph, info
