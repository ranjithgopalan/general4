"""Uploaded inputs in the artefact store (S3 at the client, a local folder here).

The platform runs in ECS: the container disk is ephemeral and the API and the worker are
different tasks. So every upload is kept in the artefact store, and the local corpus folder
(``workspaces/<app>/corpus``) is only a cache of it, refreshed before anything reads it.
One fixed prefix per application, next to that application's builds:

    <prefix>/<app>/_global/inputs/index.json                  what has been uploaded (source of truth)
    <prefix>/<app>/_global/inputs/re-cards/<module_key>.json  module JSON (the file the build reads)
    <prefix>/<app>/_global/inputs/re-cards-original/<file>    raw upload + mapping when the LLM fallback converted it
    <prefix>/<app>/_global/inputs/screens/catalog-v<N>.json   screens catalogue of one Word document
    <prefix>/<app>/_global/inputs/screens/v<N>/<image>        the pictures extracted from it
    <prefix>/<app>/_global/inputs/<kind>/<file>               any other corpus file: asp-source/*.asp, requirements/*.docx ...

``<app>`` is ``_library`` for the Global Library or the project id; ``<prefix>`` is FE_S3_PREFIX with
FE_ARTIFACT_STORE=s3 (the bucket) and ``fe`` under FE_ARTIFACT_ROOT with ``local``: the key layout
the card builds and the dependency-graph versions already use.

``sync_to_local`` downloads whatever the index names and is missing or different on disk (sha256),
and adopts files that are on disk but not in the store yet (uploads made before this module existed).
It never raises: callers treat the result as advisory and use whatever is on disk.
"""
from __future__ import annotations

import hashlib
import json
import logging
import mimetypes
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from app.agentic_platform.fe_core.kb.library import LIBRARY_APP_ID

logger = logging.getLogger(__name__)

INPUTS_TYPE = "inputs"
INDEX_FILE = "index.json"
MODULES_DIR = "re-cards"
ORIGINALS_DIR = "re-cards-original"
SCREENS_DIR = "screens"
_STRUCTURED_DIRS = {MODULES_DIR, ORIGINALS_DIR, SCREENS_DIR}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _safe(x: str | None) -> str:
    x = str(x or "_")
    return "".join(c for c in x if c.isalnum() or c in "-_.") or "_"


def _kind(store) -> str:
    return getattr(store, "kind", "local")


def inputs_prefix(store, settings, app_id: str = LIBRARY_APP_ID) -> str:
    """The store key under which an application's uploads live."""
    base = settings.fe_s3_prefix if _kind(store) == "s3" else "fe"
    return f"{str(base or 'fe').strip('/')}/{_safe(app_id)}/_global/{INPUTS_TYPE}"


def index_key(store, settings, app_id: str = LIBRARY_APP_ID) -> str:
    return f"{inputs_prefix(store, settings, app_id)}/{INDEX_FILE}"


def _empty_index() -> dict[str, Any]:
    return {"modules": {}, "screens": {}, "files": {}, "updated_at": None}


def read_index(store, settings, app_id: str = LIBRARY_APP_ID) -> dict[str, Any]:
    """The application's input index from the store (empty parts when there is none yet)."""
    key = index_key(store, settings, app_id)
    try:
        if store.exists(key):
            data = json.loads(store.get_bytes(key).decode("utf-8"))
            if isinstance(data, dict):
                for part in ("modules", "screens", "files"):
                    data.setdefault(part, {})
                return data
    except Exception as exc:  # noqa: BLE001
        logger.warning("library_inputs: could not read %s: %s", key, exc)
    return _empty_index()


def write_index(store, settings, index: dict[str, Any], app_id: str = LIBRARY_APP_ID) -> str:
    index["updated_at"] = _now()
    return store.put_bytes(index_key(store, settings, app_id),
                           json.dumps(index, indent=2, ensure_ascii=False).encode("utf-8"), "application/json")


def storage_info(store, settings, index: dict[str, Any] | None = None, app_id: str = LIBRARY_APP_ID) -> dict[str, Any]:
    """Where the inputs are and how many the store knows about (for status pages)."""
    index = index if index is not None else read_index(store, settings, app_id)
    prefix = inputs_prefix(store, settings, app_id)
    return {"store": _kind(store), "key": prefix, "uri": store.uri(prefix), "index": store.uri(index_key(store, settings, app_id)),
            "modules": len(index.get("modules", {})), "screens": len(index.get("screens", {})),
            "files": sum(len(v) for v in index.get("files", {}).values()), "updated_at": index.get("updated_at")}


# ---------------------------------------------------------------------------
# uploads -> store
# ---------------------------------------------------------------------------
def put_module(store, settings, *, module_key: str, path: Path, app_id: str = LIBRARY_APP_ID, gear_id: str | None = None,
               uploaded_by: str | None = None, module: str = "", pages: int = 0,
               replaced: Iterable[str] = (), originals: Iterable[Path] = ()) -> dict[str, Any]:
    """Keep a module JSON (the file the build reads) in the store and record it in the index."""
    path = Path(path)
    prefix = inputs_prefix(store, settings, app_id)
    raw = path.read_bytes()
    key = f"{prefix}/{MODULES_DIR}/{path.name}"
    uri = store.put_bytes(key, raw, "application/json")
    extra: list[dict[str, Any]] = []
    for p in originals:
        p = Path(p)
        if not p.is_file():
            continue
        data = p.read_bytes()
        k = f"{prefix}/{ORIGINALS_DIR}/{p.name}"
        store.put_bytes(k, data, mimetypes.guess_type(p.name)[0])
        extra.append({"key": k, "path": p.name, "sha256": _sha(data), "size": len(data)})
    index = read_index(store, settings, app_id)
    replaced_names = {Path(r).name for r in replaced}
    for mk in [mk for mk, m in index["modules"].items() if m.get("file") in replaced_names and mk != module_key]:
        index["modules"].pop(mk, None)
    index["modules"][module_key] = {
        "file": path.name, "key": key, "sha256": _sha(raw), "size": len(raw), "module": module, "pages": pages,
        "gear_id": gear_id or "", "uploaded_by": uploaded_by or "", "uploaded_at": _now(), "originals": extra,
    }
    write_index(store, settings, index, app_id)
    logger.info("library_inputs: %s module %s -> %s", app_id, module_key, uri)
    return {"ok": True, "store": _kind(store), "key": key, "uri": uri, "sha256": index["modules"][module_key]["sha256"],
            "index": store.uri(index_key(store, settings, app_id)), "modules_in_store": len(index["modules"])}


def put_screens(store, settings, *, version: int, screens_root: Path, app_id: str = LIBRARY_APP_ID,
                gear_id: str | None = None, uploaded_by: str | None = None) -> dict[str, Any]:
    """Keep one screens catalogue version (catalog-v<N>.json + v<N>/ pictures) in the store."""
    screens_root = Path(screens_root)
    prefix = inputs_prefix(store, settings, app_id)
    catalog_path = screens_root / f"catalog-v{int(version)}.json"
    raw = catalog_path.read_bytes()
    files: list[dict[str, Any]] = []
    ckey = f"{prefix}/{SCREENS_DIR}/{catalog_path.name}"
    store.put_bytes(ckey, raw, "application/json")
    files.append({"path": catalog_path.name, "key": ckey, "sha256": _sha(raw), "size": len(raw)})
    img_dir = screens_root / f"v{int(version)}"
    if img_dir.is_dir():
        for p in sorted(img_dir.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(screens_root).as_posix()
            data = p.read_bytes()
            k = f"{prefix}/{SCREENS_DIR}/{rel}"
            store.put_bytes(k, data, mimetypes.guess_type(p.name)[0])
            files.append({"path": rel, "key": k, "sha256": _sha(data), "size": len(data)})
    try:
        cat = json.loads(raw.decode("utf-8-sig"))
    except Exception:  # noqa: BLE001
        cat = {}
    index = read_index(store, settings, app_id)
    index["screens"][str(int(version))] = {
        "version": int(version), "catalog": catalog_path.name, "source_filename": cat.get("source_filename", ""),
        "source_sha256": cat.get("source_sha256", ""), "files": files, "gear_id": gear_id or "",
        "uploaded_by": uploaded_by or "", "uploaded_at": _now(),
    }
    write_index(store, settings, index, app_id)
    uri = store.uri(f"{prefix}/{SCREENS_DIR}")
    logger.info("library_inputs: %s screens v%s (%d file(s)) -> %s", app_id, version, len(files), uri)
    return {"ok": True, "store": _kind(store), "key": f"{prefix}/{SCREENS_DIR}", "uri": uri, "files": len(files),
            "index": store.uri(index_key(store, settings, app_id))}


def put_files(store, settings, *, kind: str, paths: Iterable[Path], app_id: str, gear_id: str | None = None,
              uploaded_by: str | None = None) -> dict[str, Any]:
    """Keep plain corpus files of one kind (asp-source/*.asp, requirements/*.docx ...) in the store,
    one index write for the whole set."""
    prefix = inputs_prefix(store, settings, app_id)
    kind = _safe(kind)
    index = read_index(store, settings, app_id)
    entries = index.setdefault("files", {}).setdefault(kind, {})
    keys: list[str] = []
    for p in paths:
        p = Path(p)
        if not p.is_file():
            continue
        data = p.read_bytes()
        key = f"{prefix}/{kind}/{p.name}"
        store.put_bytes(key, data, mimetypes.guess_type(p.name)[0])
        entries[p.name] = {"key": key, "sha256": _sha(data), "size": len(data), "gear_id": gear_id or "",
                           "uploaded_by": uploaded_by or "", "uploaded_at": _now()}
        keys.append(key)
    write_index(store, settings, index, app_id)
    uri = store.uri(f"{prefix}/{kind}")
    logger.info("library_inputs: %s %s: %d file(s) -> %s", app_id, kind, len(keys), uri)
    return {"ok": True, "store": _kind(store), "key": f"{prefix}/{kind}", "uri": uri, "files": len(keys), "keys": keys,
            "files_in_store": len(entries)}


def keep_upload(store, settings, *, app_id: str, document_kind: str, reply: dict[str, Any], gear_id: str | None = None,
                uploaded_by: str | None = None) -> dict[str, Any]:
    """Push what the re-cards / screens upload handler just wrote to the local corpus into the store,
    using the handler's reply to find the files."""
    corpus = Path(settings.corpus_root_for(app_id))
    if document_kind == "re-cards":
        stored = reply.get("stored") or {}
        module_key = reply.get("module_key") or Path(stored.get("file") or "module.json").stem
        path = corpus / MODULES_DIR / (stored.get("file") or f"{module_key}.json")
        originals: list[Path] = []
        if reply.get("fallback"):
            odir = corpus / ORIGINALS_DIR
            originals = [odir / Path(reply.get("filename") or "").name, odir / f"{module_key}.mapping.json"]
        return put_module(store, settings, module_key=module_key, path=path, app_id=app_id, gear_id=gear_id,
                          uploaded_by=uploaded_by, module=reply.get("module", ""), pages=int(reply.get("pages") or 0),
                          replaced=stored.get("replaced") or [], originals=originals)
    if document_kind == "screens":
        version = reply.get("catalog_version")
        if not version:
            return {"ok": False, "error": "the upload reply names no catalogue version"}
        return put_screens(store, settings, version=int(version), screens_root=corpus / SCREENS_DIR, app_id=app_id,
                           gear_id=gear_id, uploaded_by=uploaded_by)
    return {"ok": False, "error": f"no store mapping for document kind '{document_kind}'"}


# ---------------------------------------------------------------------------
# store -> local corpus (before status, before a build, on the worker)
# ---------------------------------------------------------------------------
def adopt_local(store, settings, corpus_root: Path, index: dict[str, Any], app_id: str = LIBRARY_APP_ID) -> list[str]:
    """Push files that are on local disk but not in the store (uploads made before the store held
    the inputs). Returns what was adopted."""
    from app.agentic_platform.fe_core.kb.cards_schema import module_key_of, normalise  # noqa: PLC0415

    adopted: list[str] = []
    if not corpus_root.is_dir():
        return adopted
    known_files = {m.get("file") for m in index.get("modules", {}).values()}
    modules_dir = corpus_root / MODULES_DIR
    if modules_dir.is_dir():
        for path in sorted(modules_dir.glob("*.json")):
            if path.name in known_files:
                continue
            try:
                doc, violations, _ = normalise(json.loads(path.read_text(encoding="utf-8-sig")))
                if violations:
                    continue
                put_module(store, settings, module_key=module_key_of(doc, path.stem), path=path, app_id=app_id,
                           module=doc.get("module", ""), pages=len(doc.get("pages", [])), uploaded_by="adopted-from-disk")
                adopted.append(f"{MODULES_DIR}/{path.name}")
            except Exception as exc:  # noqa: BLE001
                logger.warning("library_inputs: could not adopt %s: %s", path.name, exc)
    screens_root = corpus_root / SCREENS_DIR
    if screens_root.is_dir():
        known_versions = set(index.get("screens", {}).keys())
        for path in sorted(screens_root.glob("catalog-v*.json")):
            ver = path.stem[len("catalog-v"):]
            if not ver.isdigit() or ver in known_versions:
                continue
            try:
                put_screens(store, settings, version=int(ver), screens_root=screens_root, app_id=app_id, uploaded_by="adopted-from-disk")
                adopted.append(f"{SCREENS_DIR}/{path.name}")
            except Exception as exc:  # noqa: BLE001
                logger.warning("library_inputs: could not adopt %s: %s", path.name, exc)
    for kind_dir in sorted(p for p in corpus_root.iterdir() if p.is_dir() and p.name not in _STRUCTURED_DIRS):
        known = set(index.get("files", {}).get(_safe(kind_dir.name), {}).keys())
        new = [p for p in sorted(kind_dir.iterdir()) if p.is_file() and p.name not in known]
        if not new:
            continue
        try:
            put_files(store, settings, kind=kind_dir.name, paths=new, app_id=app_id, uploaded_by="adopted-from-disk")
            adopted.extend(f"{kind_dir.name}/{p.name}" for p in new)
        except Exception as exc:  # noqa: BLE001
            logger.warning("library_inputs: could not adopt %s/: %s", kind_dir.name, exc)
    return adopted


def sync_to_local(store, settings, corpus_root: Path | None = None, *, app_id: str = LIBRARY_APP_ID,
                  adopt: bool = True) -> dict[str, Any]:
    """Bring the local corpus folder up to date with the store's index (download by sha256).
    Never raises: a failure is reported in the result, and whatever is on disk is still used."""
    corpus_root = Path(corpus_root or settings.corpus_root_for(app_id))
    prefix = inputs_prefix(store, settings, app_id)
    out: dict[str, Any] = {"ok": True, "store": _kind(store), "app_id": app_id, "uri": store.uri(prefix), "modules": 0,
                           "screens": 0, "files": 0, "downloaded": [], "up_to_date": 0, "adopted": [], "failed": []}
    try:
        index = read_index(store, settings, app_id)
        if adopt:
            out["adopted"] = adopt_local(store, settings, corpus_root, index, app_id)
            if out["adopted"]:
                index = read_index(store, settings, app_id)
    except Exception as exc:  # noqa: BLE001
        logger.warning("library_inputs: sync of %s skipped: %s", app_id, exc)
        return {**out, "ok": False, "error": str(exc)[:300]}

    def fetch(key: str, dest: Path, sha: str | None) -> None:
        if dest.is_file() and (sha is None or _sha(dest.read_bytes()) == sha):
            out["up_to_date"] += 1
            return
        try:
            data = store.get_bytes(key)
        except Exception as exc:  # noqa: BLE001
            out["failed"].append(f"{key}: {exc}")
            return
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        out["downloaded"].append(dest.relative_to(corpus_root).as_posix())

    for mk, m in index.get("modules", {}).items():
        out["modules"] += 1
        fetch(m["key"], corpus_root / MODULES_DIR / (m.get("file") or f"{mk}.json"), m.get("sha256"))
        for o in m.get("originals", []):
            fetch(o["key"], corpus_root / ORIGINALS_DIR / o["path"], o.get("sha256"))
    for _ver, s in index.get("screens", {}).items():
        out["screens"] += 1
        for f in s.get("files", []):
            fetch(f["key"], corpus_root / SCREENS_DIR / f["path"], f.get("sha256"))
    for kind, entries in index.get("files", {}).items():
        for name, f in entries.items():
            out["files"] += 1
            fetch(f["key"], corpus_root / kind / name, f.get("sha256"))
    out["ok"] = not out["failed"]
    if out["downloaded"] or out["adopted"]:
        logger.info("library_inputs: synced %s into %s: %d downloaded, %d adopted, %d up to date",
                    app_id, corpus_root, len(out["downloaded"]), len(out["adopted"]), out["up_to_date"])
    return out
