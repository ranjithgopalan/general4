import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

import {
  AidlcPlatformMgmtService,
  AspSourceResult,
  ScopePage,
  ScopeProposal,
  ScopePrompt,
  ScopeVocabulary,
} from "../services/aidlc-platform-mgmt.service";
import { WorkspaceStore } from "../services/workspace.store";

type IntakeMode = 'scope' | 'asp' | 're-graph';

/** Onboard a workspace — project title, description, and requirements source choice. */
@Component({
  selector: "app-apm-onboard",
  template: `
    <div class="apm-crumb">No project</div>
    <div class="apm-hdr">
      <div class="apm-hdr-icon">✦</div>
      <div>
        <h2>Onboard a Workspace</h2>
        <p class="sub">Opens a Global Workspace for this project. Spends no tokens and is safe to repeat.</p>
      </div>
    </div>

    <div class="apm-banner ok" *ngIf="notice">{{ notice }}</div>
    <div class="apm-banner bad" *ngIf="error">{{ error }}</div>

    <div class="apm-card">
      <div class="apm-card-head"><h4>Project details</h4></div>
      <div class="apm-card-body">

        <div class="apm-field">
          <label>Project title</label>
          <input [(ngModel)]="name" placeholder="e.g. UW Credit Risk" />
          <p class="apm-field-hint">Used to identify the project and resolve its KB application.</p>
        </div>

        <div class="apm-field">
          <label>Project description</label>
          <textarea rows="4" [(ngModel)]="description"
                    placeholder="Brief description of the project scope and goals…"></textarea>
        </div>

        <div class="apm-field">
          <label>Gear ID</label>
          <select [(ngModel)]="gearId" (ngModelChange)="onGearChange()"
                  style="padding:8px;border:1px solid var(--border);border-radius:8px;font:inherit;width:100%;">
            <option value="">— Default (from config) —</option>
            <ng-container *ngIf="gears.length; else fixedGears">
              <option *ngFor="let g of gears" [value]="g.gear_id">{{ g.gear_id }}{{ g.current ? '' : ' (no current dependency graph)' }}</option>
            </ng-container>
            <ng-template #fixedGears>
              <option value="japan">japan</option>
              <option value="1429">1429 (UW credit)</option>
            </ng-template>
          </select>
          <p class="apm-field-hint">The application identifier for the Global Library and RE Graph context. Gear IDs with a dependency graph are listed first.</p>
        </div>

        <!-- Requirements source toggle -->
        <div class="apm-field" style="margin-bottom:6px;">
          <label>Requirements source</label>
          <div class="apm-radio-row" style="margin-top:6px;">
            <label class="apm-radio-card" [class.on]="intakeMode==='scope'" (click)="intakeMode='scope'">
              <input type="radio" name="intakeMode" value="scope" [checked]="intakeMode==='scope'" />
              <div>
                <b>Describe the business scope</b>
                <em>Say what the workspace is about in business terms. The platform finds the matching pages and their cards in the Global Library and follows their dependencies. No ASP files needed.</em>
              </div>
            </label>
            <label class="apm-radio-card" [class.on]="intakeMode==='asp'" (click)="intakeMode='asp'">
              <input type="radio" name="intakeMode" value="asp" [checked]="intakeMode==='asp'" />
              <div>
                <b>Upload ASP files (Library)</b>
                <em>Cards are selected from the approved Global Library by matching your ASP file names.</em>
              </div>
            </label>
            <label class="apm-radio-card" [class.on]="intakeMode==='re-graph'" (click)="intakeMode='re-graph'">
              <input type="radio" name="intakeMode" value="re-graph" [checked]="intakeMode==='re-graph'" />
              <div>
                <b>Use RE Graph</b>
                <em>Rules are fetched live from the RE Graph API when the PRD stage runs. No document upload needed.</em>
              </div>
            </label>
          </div>
        </div>

        <!-- Business scope (shown only when intakeMode === 'scope') -->
        <div *ngIf="intakeMode==='scope'">

          <!-- What can I write? the library's own vocabulary for this Gear ID -->
          <div class="apm-vocab" *ngIf="gearId">
            <div class="apm-vocab-head">
              <b>What can I write?</b>
              <span class="sub" *ngIf="vocab">Words the Global Library of Gear ID {{ vocab.gear_id }} knows ({{ vocab.pages }} pages, cards {{ vocab.cards_version || 'not built yet' }}). Click to fill the fields.</span>
              <span class="sub" *ngIf="busyVocab">Reading the library…</span>
              <span class="sub" *ngIf="!busyVocab && !vocab">No dependency graph for this Gear ID yet: upload the module JSON to the Global Library first.</span>
              <button type="button" class="apm-btn outline sm" *ngIf="vocab?.example?.functions?.length" (click)="useExample()">Use example</button>
              <button type="button" class="apm-btn outline sm" *ngIf="vocab" (click)="vocabOpen = !vocabOpen">{{ vocabOpen ? 'Hide' : 'Show' }}</button>
            </div>
            <ng-container *ngIf="vocab && vocabOpen">
              <div class="apm-vocab-group" *ngIf="vocab.areas.length">
                <label>Business areas</label>
                <div class="apm-vocab-chips">
                  <button type="button" class="apm-vocab-chip" *ngFor="let a of vocab.areas" [class.on]="scopeArea === a.value"
                          [title]="(a.modules || []).join(', ')" (click)="setArea(a.value)">{{ a.value }}<i>{{ a.pages }} page{{ a.pages === 1 ? '' : 's' }}</i></button>
                </div>
              </div>
              <div class="apm-field-row">
                <div class="apm-vocab-group" *ngIf="vocab.modules.length">
                  <label>Modules <span style="text-transform:none;letter-spacing:0;">(click to take every page of it)</span></label>
                  <div class="apm-vocab-chips">
                    <button type="button" class="apm-vocab-chip" *ngFor="let m of vocab.modules" [class.on]="hasListItem(scopeModules, m.value)"
                            (click)="scopeModules = addToList(scopeModules, m.value)">{{ m.value }}<i>{{ m.pages }} page{{ m.pages === 1 ? '' : 's' }}</i></button>
                  </div>
                </div>
                <div class="apm-vocab-group" *ngIf="vocab.submodules.length">
                  <label>Sub-modules <span style="text-transform:none;letter-spacing:0;">(one per page; click to take that page)</span></label>
                  <div class="apm-vocab-chips">
                    <button type="button" class="apm-vocab-chip" *ngFor="let s of vocab.submodules" [class.on]="hasListItem(scopeSubmodules, s.value)"
                            [title]="s.page + (s.domain ? ' · ' + s.domain : '') + (s.navigation ? ' · navigation page' : '')"
                            (click)="scopeSubmodules = addToList(scopeSubmodules, s.value)">{{ s.value }}<i>{{ s.page }}</i></button>
                  </div>
                </div>
              </div>
              <div class="apm-vocab-group" *ngIf="vocab.functions.length">
                <label>Business functions <span style="text-transform:none;letter-spacing:0;">(the library's requirements and rules; click to add a line)</span></label>
                <div class="apm-vocab-chips" [style.max-height]="showAllFunctions ? 'none' : null">
                  <button type="button" class="apm-vocab-chip" *ngFor="let f of vocab.functions" [class.on]="hasFunction(f.value)"
                          [title]="(f.pages || []).join(', ')" (click)="addFunction(f.value)">{{ f.value }}<i>{{ f.kind }}</i></button>
                </div>
                <button type="button" class="apm-btn outline sm" style="margin-top:6px;" *ngIf="vocab.functions.length > 12"
                        (click)="showAllFunctions = !showAllFunctions">{{ showAllFunctions ? 'Show less' : 'Show all ' + vocab.functions.length }}</button>
              </div>
              <div class="apm-field-row">
                <div class="apm-vocab-group" *ngIf="vocab.data.length">
                  <label>Business data</label>
                  <div class="apm-vocab-chips">
                    <button type="button" class="apm-vocab-chip" *ngFor="let d of vocab.data" [class.on]="hasListItem(scopeData, d.value)"
                            [title]="d.entity + ' · ' + d.pages + ' page(s)'" (click)="scopeData = addToList(scopeData, d.value)">{{ d.value }}<i>{{ d.pages }}</i></button>
                  </div>
                </div>
                <div class="apm-vocab-group" *ngIf="vocab.roles.length">
                  <label>Users / roles</label>
                  <div class="apm-vocab-chips">
                    <button type="button" class="apm-vocab-chip" *ngFor="let r of vocab.roles" [class.on]="hasListItem(scopeRoles, r.value)"
                            (click)="scopeRoles = addToList(scopeRoles, r.value)">{{ r.value }}<i>{{ r.pages }}</i></button>
                  </div>
                </div>
              </div>
              <div class="apm-vocab-group" *ngIf="vocab.navigation.length">
                <label>Usually out of scope</label>
                <div class="apm-vocab-chips">
                  <button type="button" class="apm-vocab-chip" *ngFor="let n of vocab.navigation" [class.on]="hasListItem(scopeOut, n.value)"
                          [title]="n.page" (click)="scopeOut = addToList(scopeOut, n.value)">{{ n.value }}<i>{{ n.page }}</i></button>
                </div>
              </div>
              <ul class="apm-vocab-rules"><li *ngFor="let r of vocab.rules">{{ r }}</li></ul>
            </ng-container>
          </div>

          <div class="apm-field-row">
            <div class="apm-field">
              <label>Business area</label>
              <input [(ngModel)]="scopeArea" placeholder="e.g. Credit Risk Management – Company Administration" />
            </div>
            <div class="apm-field">
              <label>Users / roles <span style="font-weight:400;color:var(--text-secondary)">(optional)</span></label>
              <input [(ngModel)]="scopeRoles" placeholder="e.g. RM Admin, Credit Officer" />
            </div>
          </div>
          <div class="apm-field-row">
            <div class="apm-field">
              <label>Module <span style="font-weight:400;color:var(--text-secondary)">(optional: every page of the module is taken)</span></label>
              <input [(ngModel)]="scopeModules" placeholder="e.g. UWCR - Credit Company Administration" />
            </div>
            <div class="apm-field">
              <label>Sub-modules <span style="font-weight:400;color:var(--text-secondary)">(optional: exactly those pages are taken)</span></label>
              <input [(ngModel)]="scopeSubmodules" placeholder="e.g. CompanySearchHandler, CompanyDetailViewer" />
            </div>
          </div>
          <div class="apm-field">
            <label>Business functions in scope <span style="font-weight:400;color:var(--text-secondary)">(one per line, verb + object)</span></label>
            <textarea rows="5" [(ngModel)]="scopeFunctions"
                      placeholder="search companies by keyword or by first letter and view the result list
select a company and view its details
create a new company, including a parent company when it does not exist
update company details and the ORR grade, keeping the change history
delete a company and notify the admin and technical teams by email"></textarea>
            <p class="apm-field-hint">These lines are matched against the Global Library cards (business rules, functional requirements, screens). The dependency graph then adds the pages they post to or navigate to.</p>
          </div>
          <div class="apm-field-row">
            <div class="apm-field">
              <label>Key business data <span style="font-weight:400;color:var(--text-secondary)">(optional)</span></label>
              <input [(ngModel)]="scopeData" placeholder="e.g. Company, ORR grade, Activity log" />
            </div>
            <div class="apm-field">
              <label>Out of scope <span style="font-weight:400;color:var(--text-secondary)">(optional)</span></label>
              <input [(ngModel)]="scopeOut" placeholder="e.g. admin menu, login / logout" />
            </div>
          </div>
          <div class="apm-field-row">
            <div class="apm-field">
              <label>Include as context <span style="font-weight:400;color:var(--text-secondary)">(optional)</span></label>
              <input [(ngModel)]="scopeContext" placeholder="e.g. export sync to downstream systems" />
            </div>
            <div class="apm-field">
              <label>Purpose <span style="font-weight:400;color:var(--text-secondary)">(optional)</span></label>
              <input [(ngModel)]="scopePurpose" placeholder="e.g. PRD and FRD for modernisation to Angular + Spring Boot" />
            </div>
          </div>
          <div class="apm-field">
            <label>Or paste a description <span style="font-weight:400;color:var(--text-secondary)">(optional: an email or a paragraph from the business; the function lines are picked out automatically)</span></label>
            <textarea rows="3" [(ngModel)]="scopeText"
                      placeholder="e.g. We want to modernise company administration for RM Admins: they search companies by keyword, view and update company details and the ORR grade, create new companies and delete companies with an email notification."></textarea>
          </div>
          <div style="display:flex;gap:8px;align-items:center;margin-bottom:12px;">
            <button type="button" class="apm-btn outline" [disabled]="busyPropose || !canPropose()" (click)="proposeScope()">
              {{ busyPropose ? 'Scanning the library…' : (proposal ? 'Propose again' : 'Propose scope') }}
            </button>
            <span class="sub" *ngIf="!gearId">select a Gear ID first: the scope is resolved on its dependency graph</span>
            <span class="sub" *ngIf="gearId && !canPropose()">pick a module or sub-module, add a business function, or paste a description</span>
          </div>

          <!-- Proposal -->
          <div *ngIf="proposal" style="padding:12px;background:var(--surface-2,#f5f5f5);border-radius:8px;font-size:13px;margin-bottom:12px;">
            <b style="display:block;margin-bottom:2px;">
              Proposed scope on dependency graph v{{ proposal.version }} of Gear ID {{ proposal.gear_id }}
              <span class="sub" style="font-weight:400;margin-left:6px;">cards {{ proposal.cards_version || '(none built)' }} · search {{ proposal.search }}</span>
            </b>
            <div class="sub" style="margin-bottom:8px;">
              {{ selected.size }} page(s) selected ·
              <span *ngFor="let k of cardKinds" style="margin-right:8px;">{{ k }}: {{ selectedCards()[k] || 0 }}</span>
              <span *ngIf="proposal.totals?.shared_entities">· {{ proposal.totals?.shared_entities }} shared entities</span>
            </div>
            <div *ngFor="let n of proposal.notes || []" style="color:#b45309;font-size:12px;">⚠ {{ n }}</div>

            <div class="apm-scope-section" *ngIf="proposal.in_scope.length">
              <b>In scope ({{ proposal.in_scope.length }})</b> <span class="sub">— pages matched by your description and the pages they post to or navigate to</span>
              <div class="apm-scope-row hd"><span></span><span>Page</span><span>Module / sub-module</span><span>How</span><span>Why</span><span>Cards</span></div>
              <div class="apm-scope-row" *ngFor="let p of proposal.in_scope" [class.off]="!selected.has(p.file)">
                <input type="checkbox" [checked]="selected.has(p.file)" (change)="toggle(p.file)" />
                <span class="mono">{{ p.file }}</span>
                <span>{{ p.library_module || p.module_name || p.module }}<span class="reason" *ngIf="p.library_submodule || p.submodule"> / {{ p.library_submodule || p.submodule }}</span></span>
                <span>{{ p.role === 'seed' ? 'matched' : ('reached, ' + p.hop + ' hop' + (p.hop === 1 ? '' : 's')) }}<span class="reason" *ngIf="p.via?.from"><br/>via {{ p.via?.from }}</span></span>
                <span class="reason">{{ why(p) }}</span>
                <span class="reason">{{ cardsLine(p.cards) }}</span>
              </div>
            </div>

            <div class="apm-scope-section" *ngIf="proposal.context.length">
              <b>Context — other modules ({{ proposal.context.length }})</b> <span class="sub">— referenced by the scope but belonging to another module; tick to include</span>
              <div class="apm-scope-row" *ngFor="let p of proposal.context" [class.off]="!selected.has(p.file)">
                <input type="checkbox" [checked]="selected.has(p.file)" (change)="toggle(p.file)" />
                <span class="mono">{{ p.file }}</span>
                <span>{{ p.library_module || p.module_name || p.module }}</span>
                <span>reached, {{ p.hop }} hop{{ p.hop === 1 ? '' : 's' }}<span class="reason" *ngIf="p.via?.from"><br/>via {{ p.via?.from }}</span></span>
                <span class="reason">{{ p.via?.evidence || '' }}</span>
                <span class="reason">{{ cardsLine(p.cards) }}</span>
              </div>
            </div>

            <div class="apm-scope-section" *ngIf="proposal.suggested.length">
              <b>Suggested ({{ proposal.suggested.length }})</b> <span class="sub">— only a reference found in the rule text leads there; tick if it belongs</span>
              <div class="apm-scope-row" *ngFor="let s of proposal.suggested" [class.off]="!selected.has(s.page)">
                <input type="checkbox" [checked]="selected.has(s.page)" (change)="toggle(s.page)" />
                <span class="mono">{{ s.page }}</span>
                <span>{{ s.module_name || s.module }}</span>
                <span>from {{ s.from }}</span>
                <span class="reason">{{ s.evidence || '' }}</span>
                <span class="reason">{{ cardsLine(s.cards) }}</span>
              </div>
            </div>

            <div class="apm-scope-section" *ngIf="proposal.excluded.length">
              <b>Left out ({{ proposal.excluded.length }})</b>
              <span class="sub" *ngFor="let e of proposal.excluded; let last = last"> <span class="mono">{{ e.page }}</span> ({{ e.reason }}){{ last ? '' : ',' }}</span>
            </div>
          </div>
        </div>

        <!-- ASP file upload (shown only when intakeMode === 'asp') -->
        <div *ngIf="intakeMode==='asp'">
          <div class="apm-field">
            <label>ASP files <span style="font-weight:400;color:var(--text-secondary)">(required, multi-select)</span></label>
            <input #aspInput type="file" accept=".asp,.asa,.inc" multiple (change)="pickAsp($event)" hidden />
            <input #txtInput type="file" accept=".txt" (change)="pickAspFromText($event)" hidden />
            <div class="apm-file-pick">
              <button type="button" class="apm-btn outline" (click)="aspInput.click()">Choose ASP files…</button>
              <span class="sub">{{ aspLabel }}</span>
            </div>
            <!-- Text file fallback -->
            <div style="display:flex;align-items:center;gap:8px;margin-top:8px;">
              <span style="font-size:12px;color:var(--text-secondary);">or</span>
              <button type="button" class="apm-btn outline" style="font-size:12px;padding:4px 10px;"
                      (click)="txtInput.click()">Upload names from .txt…</button>
              <span *ngIf="txtLabel" style="font-size:12px;color:var(--text-secondary);">{{ txtLabel }}</span>
            </div>
            <p class="apm-field-hint">
              Upload your project's <code>.asp</code>, <code>.asa</code>, or <code>.inc</code> files.
              Only the file names are used to select matching cards from the approved Global Library.
              Ensure the library is built and approved before onboarding.
              <br/>
              <b>Fallback:</b> upload a <code>.txt</code> file listing one ASP filename per line — names are extracted and matched automatically.
            </p>
          </div>
        </div>

        <div *ngIf="uploadProgress" class="apm-banner" style="background:#e6f3fb;border-color:#b3d9f0;color:#0369a1;margin-bottom:8px;">
          {{ uploadProgress }}
        </div>
        <!-- ASP / scope result -->
        <div *ngIf="aspResult" style="padding:12px;background:var(--surface-2,#f5f5f5);border-radius:8px;font-size:13px;margin-bottom:12px;">
          <b style="display:block;margin-bottom:4px;">✔ {{ aspResult.matched.length }} pages matched · {{ aspResult.cards_selected ?? 0 }} cards selected</b>
          <span *ngIf="aspResult.unmatched.length" style="color:#b45309;">
            {{ aspResult.unmatched.length }} unmatched: {{ aspResult.unmatched.join(', ') }}
          </span>
        </div>

        <!-- RE Graph info banner (shown only when intakeMode === 're-graph') -->
        <div class="apm-banner" *ngIf="intakeMode==='re-graph'"
             style="background:#e6f3fb;border-color:#b3d9f0;color:#0369a1;margin-bottom:14px;">
          <b>RE Graph will be called at PRD run time.</b><br/>
          When you click <b>▶ Run agent</b> on the PRD stage, a dialog will ask for the
          extraction scope (Whole Application or Specific Module). The gear_id is resolved
          from the workspace config — no document upload needed here.
        </div>

        <div style="display:flex;gap:8px;align-items:center;margin-top:14px">
          <button class="apm-btn"
                  [disabled]="!name.trim() || busy || (intakeMode==='asp' && aspFiles.length === 0) || (intakeMode==='scope' && selected.size === 0)"
                  (click)="submit()">
            {{ busy ? 'Onboarding…' : 'Onboard workspace' }}
          </button>
          <button class="apm-btn outline" (click)="cancel()">Cancel</button>
          <span class="sub" *ngIf="!name.trim()">a project title is required</span>
          <span class="sub" *ngIf="name.trim() && intakeMode==='asp' && aspFiles.length === 0">at least one ASP file is required</span>
          <span class="sub" *ngIf="name.trim() && intakeMode==='scope' && selected.size === 0">propose a scope and keep at least one page</span>
        </div>

      </div>
    </div>
  `,
})
export class OnboardComponent implements OnInit {
  name = "";
  description = "";
  gearId = "";
  gears: { gear_id: string; versions: number; current: string | null; latest: string | null }[] = [];
  uploadProgress = "";
  busy = false;
  notice = "";
  error = "";
  intakeMode: IntakeMode = 'scope';

  // ASP files
  aspFiles: File[] = [];
  aspLabel = "No files chosen";
  aspResult: AspSourceResult | null = null;
  txtLabel = "";

  // Business scope
  scopeArea = "";
  scopeModules = "";
  scopeSubmodules = "";
  scopeRoles = "";
  scopeFunctions = "";
  scopeData = "";
  scopeContext = "";
  scopeOut = "";
  scopePurpose = "";
  scopeText = "";
  busyPropose = false;
  proposal: ScopeProposal | null = null;
  selected = new Set<string>();
  readonly cardKinds = ["BR", "FR", "SCR", "CMP", "API", "ENT", "WF"];

  // The library's vocabulary for the selected Gear ID ("What can I write?")
  vocab: ScopeVocabulary | null = null;
  /** Collapsed by default: the header line, "Use example" and "Show" are enough until the user wants the lists. */
  vocabOpen = false;
  busyVocab = false;
  showAllFunctions = false;

  constructor(
    private readonly svc: AidlcPlatformMgmtService,
    private readonly store: WorkspaceStore,
    private readonly router: Router,
  ) {}

  ngOnInit(): void {
    this.store.clearProject();
    this.svc.libraryGraphGears().subscribe((r) => {
      this.gears = r?.items ?? [];
      if (!this.gearId && this.gears.length === 1) this.gearId = this.gears[0].gear_id;
      if (this.gearId) this.loadVocabulary();
    });
  }

  // ── "What can I write?" ──────────────────────────────────────────────────
  onGearChange(): void {
    this.proposal = null;
    this.selected = new Set<string>();
    this.loadVocabulary();
  }

  loadVocabulary(): void {
    this.vocab = null;
    if (!this.gearId) return;
    this.busyVocab = true;
    const gear = this.gearId;
    this.svc.libraryScopeVocabulary(gear).subscribe((v) => {
      this.busyVocab = false;
      if (this.gearId === gear) this.vocab = v;
    });
  }

  setArea(value: string): void {
    this.scopeArea = this.scopeArea === value ? "" : value;
  }

  hasFunction(value: string): boolean {
    return this.functionLines().some(l => l.toLowerCase() === value.toLowerCase());
  }

  addFunction(value: string): void {
    const lines = this.functionLines();
    const i = lines.findIndex(l => l.toLowerCase() === value.toLowerCase());
    if (i >= 0) lines.splice(i, 1); else lines.push(value);
    this.scopeFunctions = lines.join("\n");
  }

  hasListItem(field: string, value: string): boolean {
    return field.split(/,|;|\r?\n/).map(x => x.trim().toLowerCase()).includes(value.toLowerCase());
  }

  addToList(field: string, value: string): string {
    const items = field.split(/,|;|\r?\n/).map(x => x.trim()).filter(Boolean);
    const i = items.findIndex(x => x.toLowerCase() === value.toLowerCase());
    if (i >= 0) items.splice(i, 1); else items.push(value);
    return items.join(", ");
  }

  useExample(): void {
    const e = this.vocab?.example;
    if (!e) return;
    this.scopeArea = e.business_area || "";
    this.scopeModules = (e.modules || []).join(", ");
    this.scopeSubmodules = (e.submodules || []).join(", ");
    this.scopeRoles = (e.roles || []).join(", ");
    this.scopeFunctions = (e.functions || []).join("\n");
    this.scopeData = (e.data || []).join(", ");
    this.scopeContext = (e.context || []).join(", ");
    this.scopeOut = (e.out_of_scope || []).join(", ");
    this.scopePurpose = e.purpose || "";
    this.proposal = null;
    this.selected = new Set<string>();
  }

  private functionLines(): string[] {
    return this.scopeFunctions.split(/\r?\n/).map(x => x.replace(/^[-*•\s]+/, "").trim()).filter(Boolean);
  }

  // ── ASP files ────────────────────────────────────────────────────────────
  pickAsp(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.aspFiles = input.files ? Array.from(input.files) : [];
    const count = this.aspFiles.length;
    const plural = count > 1 ? 's' : '';
    this.aspLabel = count ? `${count} file${plural} selected` : "No files chosen";
    this.aspResult = null;
    this.txtLabel = "";
  }

  pickAspFromText(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    const ASP_EXTS = ['.asp', '.asa', '.inc'];
    file.text().then(text => {
      const names = text
        .split(/\r?\n/)
        .map(l => l.trim())
        .filter(l => l && ASP_EXTS.some(ext => l.toLowerCase().endsWith(ext)));
      this.aspFiles = names.map(name => new File([" "], name));
      this.aspLabel = this.aspFiles.length
        ? `${this.aspFiles.length} ASP name(s) extracted from text file`
        : "No valid ASP names found in file";
      this.txtLabel = file.name;
      this.aspResult = null;
    });
  }

  // ── Business scope ───────────────────────────────────────────────────────
  canPropose(): boolean {
    return !!this.gearId && (!!this.scopeFunctions.trim() || !!this.scopeText.trim() || !!this.scopeModules.trim() || !!this.scopeSubmodules.trim());
  }

  prompt(): ScopePrompt {
    const list = (s: string) => s.split(/\r?\n|;|,/).map(x => x.trim()).filter(Boolean);
    const p: ScopePrompt = {
      business_area: this.scopeArea.trim(),
      modules: list(this.scopeModules),
      submodules: list(this.scopeSubmodules),
      roles: list(this.scopeRoles),
      functions: this.functionLines(),
      data: list(this.scopeData),
      context: list(this.scopeContext),
      out_of_scope: list(this.scopeOut),
      purpose: this.scopePurpose.trim(),
    };
    if (this.scopeText.trim()) p.text = this.scopeText.trim();
    return p;
  }

  proposeScope(): void {
    this.busyPropose = true;
    this.error = "";
    this.proposal = null;
    this.selected = new Set<string>();
    this.svc.libraryScopePropose({ gear_id: this.gearId, prompt: this.prompt(), policy: {} }).subscribe({
      next: (r) => {
        this.busyPropose = false;
        if (!r) { this.error = "The library could not be scanned. Check that the Gear ID has a dependency graph and that the API is reachable."; return; }
        this.proposal = r;
        this.selected = new Set<string>(r.in_scope.map(p => p.file));
        if (!r.in_scope.length) this.error = "No page matched the description. Use the words of the business functions (search, create, update…) and the business data, or widen the business area.";
      },
      error: () => { this.busyPropose = false; this.error = "The library could not be scanned."; },
    });
  }

  toggle(file: string): void {
    if (this.selected.has(file)) this.selected.delete(file); else this.selected.add(file);
  }

  why(p: ScopePage): string {
    const m = p.matched || [];
    if (m.length) return m.map(x => `"${x.line}"`).slice(0, 2).join("; ") + (m.length > 2 ? ` +${m.length - 2}` : "");
    return p.via?.evidence || "";
  }

  cardsLine(cards?: Record<string, number> | null): string {
    if (!cards) return "";
    return this.cardKinds.filter(k => cards[k]).map(k => `${k} ${cards[k]}`).join(" · ");
  }

  selectedCards(): Record<string, number> {
    const out: Record<string, number> = {};
    if (!this.proposal) return out;
    const all: { file: string; cards?: Record<string, number> | null }[] = [
      ...this.proposal.in_scope, ...this.proposal.context,
      ...this.proposal.suggested.map(s => ({ file: s.page, cards: s.cards })),
    ];
    for (const p of all) {
      if (!this.selected.has(p.file)) continue;
      for (const [k, v] of Object.entries(p.cards || {})) out[k] = (out[k] || 0) + (v || 0);
    }
    return out;
  }

  // ── Submit ───────────────────────────────────────────────────────────────
  submit(): void {
    this.busy = true;
    this.error = "";
    this.aspResult = null;
    const app = this.name.trim();
    const intakeSrc = this.intakeMode === 're-graph' ? 're-graph' : 'reverse-engineering';

    this.svc.onboard({
      kb_application: app,
      category: 'brownfield',
      intake_source: intakeSrc,
      source_language: null,
      target_framework: 'angular-springboot',
      gear_id: this.gearId || undefined,
    }).subscribe((project) => {
      if (!project) { this.busy = false; this.error = "Onboarding failed. Check the API and try again."; return; }
      if (this.intakeMode === 'asp' && this.aspFiles.length > 0) {
        this.uploadProgress = `Uploading ${this.aspFiles.length} ASP file(s)…`;
        this.svc.uploadAspSource(app, this.aspFiles, true).subscribe(result => {
          this.uploadProgress = '';
          this.aspResult = result;
          this.done();
        });
      } else if (this.intakeMode === 'scope' && this.proposal && this.selected.size > 0) {
        this.uploadProgress = `Storing the scope (${this.selected.size} page(s))…`;
        const contextNames = this.proposal.context.map(c => c.file).filter(f => !this.selected.has(f));
        this.svc.onboardScope(app, {
          gear_id: this.gearId || undefined,
          kb_version: this.proposal.kb_version,
          cards_version: this.proposal.cards_version ?? null,
          prompt: this.prompt(),
          policy: this.proposal.policy || {},
          pages: Array.from(this.selected),
          context: contextNames,
          proposal: { in_scope: this.proposal.in_scope, context: this.proposal.context, suggested: this.proposal.suggested },
          start: true,
        }).subscribe(result => {
          this.uploadProgress = '';
          this.aspResult = result;
          if (!result) { this.busy = false; this.error = "The scope could not be stored. Is the Global Library built and approved?"; return; }
          this.done();
        });
      } else {
        this.done();
      }
    });
  }

  private done(): void {
    this.busy = false;
    this.svc.listProjects().subscribe(projects => {
      this.store.projects.set(projects);
      this.router.navigate(['/aidlc-platform-management/dashboard']);
    });
  }

  cancel(): void {
    this.router.navigate(['/aidlc-platform-management/dashboard']);
  }
}
