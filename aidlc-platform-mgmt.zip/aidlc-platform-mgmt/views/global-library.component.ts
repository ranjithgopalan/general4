import { Component, OnInit } from "@angular/core";

import {
  AidlcPlatformMgmtService,
  LibraryDocumentResult,
  LibraryStatus,
  LibraryVersions,
} from "../services/aidlc-platform-mgmt.service";

/** Global Card Library — scoped per Gear ID. Upload RED JSON + screens once; projects upload ASP files. */
@Component({
  selector: "app-apm-global-library",
  template: `
    <div class="apm-crumb">Global Library</div>
    <div class="apm-hdr">
      <div class="apm-hdr-icon">📚</div>
      <div>
        <h2>Global Card Library</h2>
        <p class="sub">Upload the RED JSON and screens document once per Gear ID. Every project selects its cards by uploading ASP files.</p>
      </div>
    </div>

    <div class="apm-banner ok" *ngIf="notice">{{ notice }}</div>
    <div class="apm-banner err" *ngIf="error">{{ error }}</div>

    <!-- Step 1: Gear ID selection — gates everything below -->
    <div class="apm-card">
      <div class="apm-card-head"><h4>Application (Gear ID)</h4></div>
      <div class="apm-card-body">
        <div class="apm-field">
          <label>Gear ID</label>
          <select [(ngModel)]="gearId" (ngModelChange)="onGearChange()"
                  style="padding:8px;border:1px solid var(--border);border-radius:8px;font:inherit;width:100%;">
            <option value="">— Select Gear ID —</option>
            <option value="japan">japan</option>
            <option value="1429">1429 (UW credit)</option>
          </select>
          <p class="apm-field-hint">
            The library is stored and approved per Gear ID. Downstream agents resolve the approved library
            for a project by matching the project's Gear ID. Each Gear ID has its own S3 path, DB version,
            and approval state.
          </p>
        </div>
      </div>
    </div>

    <!-- Only show the rest once a Gear ID is selected -->
    <ng-container *ngIf="gearId">

      <!-- Upload section -->
      <div class="apm-card">
        <div class="apm-card-head">
          <h4>Upload library documents</h4>
          <span style="font-size:12px;color:var(--text-secondary);margin-left:8px;">Gear: <b>{{ gearId }}</b></span>
        </div>
        <div class="apm-card-body">

          <!-- RED JSON -->
          <div class="apm-field">
            <label>RED JSON <span style="font-weight:400;color:var(--text-secondary)">(required, one per module)</span></label>
            <input #jsonFile type="file" accept=".json" (change)="pickJson($event)" hidden />
            <div class="apm-file-pick">
              <button type="button" class="apm-btn outline" (click)="jsonFile.click()">Upload RED JSON…</button>
              <span class="sub">{{ jsonFileName || 'No file chosen' }}</span>
            </div>
            <p class="apm-field-hint">
              Cards JSON in re-cards format (BR/FR/SCR/CMP/API/ENT/WF per ASP page).
              Re-uploading replaces the existing module. Stored under Gear ID <b>{{ gearId }}</b>.
            </p>
          </div>

          <button class="apm-btn" style="margin-bottom:18px;"
                  [disabled]="!jsonFile$ || busy || autoFixing"
                  (click)="uploadJson()">
            {{ busyJson ? 'Uploading…' : 'Upload JSON' }}
          </button>

          <!-- JSON validation violations panel -->
          <div *ngIf="jsonViolations.length"
               style="margin-bottom:16px;padding:14px 16px;background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;font-size:13px;">
            <b style="display:block;margin-bottom:6px;color:#b91c1c;">
              Upload failed — {{ jsonViolations.length }} validation error{{ jsonViolations.length !== 1 ? 's' : '' }}
            </b>
            <div style="margin-bottom:6px;color:#7f1d1d;">{{ jsonViolationMessage }}</div>
            <ul style="margin:0 0 10px;padding-left:18px;color:#991b1b;line-height:1.6;">
              <li *ngFor="let v of jsonViolations.slice(0, 5)">{{ v }}</li>
              <li *ngIf="jsonViolations.length > 5" style="color:#b45309;">
                + {{ jsonViolations.length - 5 }} more — download the report to see all
              </li>
            </ul>
            <div style="margin-bottom:10px;padding:8px 10px;background:#fff7ed;border:1px solid #fdba74;border-radius:6px;color:#7c2d12;font-size:12px;">
              Each entity ID must map to exactly one database table.
              Use <b>Auto-fix</b> to assign new unique IDs to conflicting entries, or correct the JSON manually and re-upload.
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <button class="apm-btn" [disabled]="autoFixing || busyJson"
                      (click)="autoFixAndReupload()"
                      title="Reassigns new unique IDs to conflicting entities and re-uploads automatically">
                {{ autoFixing ? 'Fixing…' : busyJson ? 'Uploading…' : 'Auto-fix & Re-upload' }}
              </button>
              <button class="apm-btn outline" (click)="copyViolations()">Copy violations</button>
              <button class="apm-btn outline" (click)="downloadViolations()">Download report</button>
            </div>
          </div>

          <!-- Auto-fix change log — green on success, amber when re-upload still fails -->
          <div *ngIf="autoFixChanges.length"
               [style.background]="jsonResult ? '#f0fdf4' : '#fffbeb'"
               [style.border]="jsonResult ? '1px solid #86efac' : '1px solid #fcd34d'"
               style="margin-bottom:12px;padding:10px 14px;border-radius:8px;font-size:12px;">
            <b [style.color]="jsonResult ? '#15803d' : '#92400e'" style="display:block;margin-bottom:4px;">
              <ng-container *ngIf="jsonResult">
                Auto-fix successful — {{ autoFixChanges.length }} ID{{ autoFixChanges.length !== 1 ? 's' : '' }} reassigned
              </ng-container>
              <ng-container *ngIf="!jsonResult">
                Auto-fix applied {{ autoFixChanges.length }} change{{ autoFixChanges.length !== 1 ? 's' : '' }} — re-upload still has violations
              </ng-container>
            </b>
            <div *ngFor="let c of autoFixChanges.slice(0, 5)"
                 [style.color]="jsonResult ? '#166534' : '#78350f'">{{ c }}</div>
            <div *ngIf="autoFixChanges.length > 5"
                 [style.color]="jsonResult ? '#15803d' : '#92400e'">+ {{ autoFixChanges.length - 5 }} more</div>
          </div>

          <!-- JSON result -->
          <div *ngIf="jsonResult"
               style="margin-bottom:16px;padding:12px;background:var(--surface-2,#f5f5f5);border-radius:8px;font-size:13px;">
            <b style="display:block;margin-bottom:4px;">
              ✔ {{ jsonResult.module_key }} — {{ jsonResult.pages }} pages, {{ jsonResult.cards_total }} cards
              <span *ngIf="jsonResult.parsed_by === 'llm-fallback'"
                    style="color:#b45309;margin-left:6px;">(LLM fallback used)</span>
            </b>
            <span *ngIf="jsonResult.edges">{{ jsonResult.edges }} edges · </span>
            <ng-container *ngIf="jsonResult.cards">
              <span *ngFor="let k of cardKinds(jsonResult.cards)" style="margin-right:8px;">
                {{ k }}: {{ jsonResult.cards[k] }}
              </span>
            </ng-container>
            <div *ngFor="let w of jsonResult.warnings || []" style="color:#b45309;margin-top:4px;">⚠ {{ w }}</div>
            <div *ngIf="jsonResult.storage as s" style="margin-top:6px;font-family:monospace;font-size:11px;color:var(--text-secondary);">
              <ng-container *ngIf="s.ok !== false; else jsonStoreFailed">☁ Stored in {{ storeLabel(s.store) }}: {{ s.key || s.uri }}</ng-container>
              <ng-template #jsonStoreFailed><span style="color:#b91c1c;">⚠ Not stored in the artefact store: {{ s.error }} (kept on this host only)</span></ng-template>
            </div>
            <!-- Nothing reaches the database at upload: the build publishes cards and the dependency graph -->
            <div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--border,#e5e7eb);color:var(--text-secondary);">
              Next: <b>Build library</b> below publishes the cards and rebuilds the dependency graph in the database from the module JSONs in the store.
            </div>
          </div>

          <hr style="border:none;border-top:1px solid var(--border,#e5e7eb);margin:4px 0 16px;" />

          <!-- Screens doc -->
          <div class="apm-field">
            <label>Screens Word document <span style="font-weight:400;color:var(--text-secondary)">(optional)</span></label>
            <input #screensFile type="file" accept=".docx" (change)="pickScreens($event)" hidden />
            <div class="apm-file-pick">
              <button type="button" class="apm-btn outline" (click)="screensFile.click()">Upload screens .docx…</button>
              <span class="sub">{{ screensFileName || 'No file chosen' }}</span>
            </div>
            <p class="apm-field-hint">
              Word document with ASP file names (e.g. "File name – CompanySelect.asp") and screenshots.
              Screenshots bind to SCR cards. Re-uploading merges; newest wins per page.
            </p>
          </div>

          <button class="apm-btn" style="margin-bottom:18px;"
                  [disabled]="!screens$ || busy"
                  (click)="uploadScreens()">
            {{ busyScreens ? 'Uploading…' : 'Upload screens' }}
          </button>

          <!-- Screens result -->
          <div *ngIf="screensResult"
               style="padding:12px;background:var(--surface-2,#f5f5f5);border-radius:8px;font-size:13px;">
            <b>✔ Screens uploaded — {{ screensResult.pages }} pages, {{ screensResult.images_bound }} bound</b>
            <span *ngIf="screensResult.images_unbound" style="color:#b45309;margin-left:8px;">
              {{ screensResult.images_unbound }} unbound
            </span>
            <div *ngFor="let r of screensResult.report || []"
                 style="color:var(--text-secondary);margin-top:2px;font-size:11px;">{{ r }}</div>
            <div *ngIf="screensResult.storage as s" style="margin-top:6px;font-family:monospace;font-size:11px;color:var(--text-secondary);">
              <ng-container *ngIf="s.ok !== false; else screensStoreFailed">☁ Stored in {{ storeLabel(s.store) }}: {{ s.key || s.uri }} ({{ s.files || 0 }} file(s): catalogue + pictures)</ng-container>
              <ng-template #screensStoreFailed><span style="color:#b91c1c;">⚠ Not stored in the artefact store: {{ s.error }} (kept on this host only)</span></ng-template>
            </div>
          </div>

        </div>
      </div>

      <!-- Build -->
      <div class="apm-card">
        <div class="apm-card-head">
          <h4>Build library</h4>
          <span style="font-size:12px;color:var(--text-secondary);margin-left:8px;">Gear: <b>{{ gearId }}</b></span>
        </div>
        <div class="apm-card-body">
          <p class="sub" style="margin-bottom:12px;">
            Merges all modules for Gear ID <b>{{ gearId }}</b>, binds screenshots, writes the page index to S3
            and KB version to the database. A build must be approved before any project under this Gear ID can use it.
            <span *ngIf="status?.dirty" style="color:#b45309;font-weight:500;margin-left:4px;">Unbuilt changes pending.</span>
          </p>
          <button class="apm-btn"
                  [disabled]="busyBuild || !hasCorpus()"
                  (click)="build()">
            {{ busyBuild ? 'Building…' : 'Build library' }}
          </button>
          <span class="sub" style="margin-left:10px;" *ngIf="!hasCorpus()">Upload at least one JSON module first</span>
          <div *ngIf="buildNotice"
               class="apm-banner"
               style="margin-top:12px;background:#e6f3fb;border-color:#b3d9f0;color:#0369a1;">
            {{ buildNotice }}
          </div>

          <!-- Refresh button — poll build state without page reload -->
          <button *ngIf="status?.latest_build && !isPendingApproval() && !status?.approved"
                  type="button" class="apm-btn outline"
                  style="margin-top:10px;font-size:12px;"
                  (click)="loadStatus()">
            Refresh status
          </button>

          <!-- Approve banner — shown when the latest build is waiting for approval -->
          <div *ngIf="isPendingApproval()"
               style="margin-top:14px;padding:14px 16px;background:#fff8e1;border:1px solid #fcd34d;border-radius:8px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
            <span style="flex:1;font-size:13px;color:#78350f;">
              <b>Build waiting for approval</b> — run <code style="font-size:11px;">{{ status?.latest_build?.run_id }}</code>
              <span *ngIf="status?.latest_build?.built_at" style="margin-left:6px;color:#92400e;">
                · completed {{ status?.latest_build?.built_at | date:'shortTime' }}
              </span>
            </span>
            <button class="apm-btn"
                    [disabled]="approving"
                    (click)="approveLatestBuild()"
                    style="background:#15803d;border-color:#15803d;white-space:nowrap;">
              {{ approving ? 'Approving…' : 'Approve build' }}
            </button>
          </div>
          <div *ngIf="approveError" class="apm-banner err" style="margin-top:8px;">{{ approveError }}</div>
        </div>
      </div>

      <!-- Library status at bottom - collapsible -->
      <div class="apm-card" *ngIf="status">
        <div class="apm-card-head" style="cursor:pointer;" (click)="statusCollapsed=!statusCollapsed">
          <button type="button" style="background:none;border:none;padding:0;margin-right:8px;cursor:pointer;font-size:14px;color:var(--text-secondary);">{{ statusCollapsed ? '▸' : '▾' }}</button>
          <h4 style="display:inline;">Library status</h4>
          <span style="font-size:12px;color:var(--text-secondary);margin-left:8px;">Gear: <b>{{ gearId }}</b></span>
        </div>
        <div class="apm-card-body" [hidden]="statusCollapsed" style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;">
          <div class="apm-stat-tile">
            <div class="apm-stat-val">{{ status.corpus.modules.length }}</div>
            <div class="apm-stat-lbl">Modules (JSON)</div>
          </div>
          <div class="apm-stat-tile">
            <div class="apm-stat-val">{{ status.corpus.screens.length }}</div>
            <div class="apm-stat-lbl">Screen catalogues</div>
          </div>
          <div class="apm-stat-tile"
               [style.background]="status.approved ? '#edfdf5' : (status.latest_build ? '#fff8e1' : '#fafafa')"
               [style.border-color]="status.approved ? '#86efac' : (status.latest_build ? '#fcd34d' : '#e5e7eb')">
            <div class="apm-stat-val"
                 [style.color]="status.approved ? '#15803d' : (status.latest_build ? '#b45309' : '#6b7280')">
              {{ status.approved ? 'Approved' : (status.latest_build ? 'Pending approval' : 'Not built') }}
            </div>
            <div class="apm-stat-lbl">Build state</div>
          </div>
        </div>
        <div class="apm-card-body" [hidden]="statusCollapsed" style="padding-top:0;border-top:1px solid var(--border,#e5e7eb);margin-top:4px;">
          <p class="sub" style="margin-bottom:6px;font-size:11px;">Storage for Gear ID <b>{{ gearId }}</b>:</p>
          <div style="font-family:monospace;font-size:11px;color:var(--text-secondary);line-height:1.8;">
            <ng-container *ngIf="status.storage as st">
              <div *ngIf="!st.error; else storageError">
                {{ storeLabel(st.store) }} uploads: <b>{{ st.key || st.uri }}</b>
                <span style="margin-left:6px;">({{ st.modules || 0 }} module JSON, {{ st.screens || 0 }} screens document)</span>
                <span *ngIf="st.synced?.downloaded?.length" style="color:#15803d;margin-left:6px;">· {{ st.synced?.downloaded?.length }} file(s) synced to the build corpus</span>
                <span *ngIf="st.synced?.adopted?.length" style="color:#b45309;margin-left:6px;">· {{ st.synced?.adopted?.length }} file(s) adopted from disk</span>
                <span *ngIf="st.synced && st.synced.ok === false" style="color:#b91c1c;margin-left:6px;">
                  · sync failed: {{ st.synced.error || (st.synced.failed?.length ? st.synced.failed[0] : 'unknown error') }}
                  <span *ngIf="st.synced.failed?.length > 1"> (+{{ st.synced.failed.length - 1 }} more — check server logs)</span>
                </span>
              </div>
              <ng-template #storageError><div style="color:#b91c1c;">Artefact store not reachable: {{ st.error }}</div></ng-template>
              <div>{{ storeLabel(st.store) }} builds: <b>fe/_library/&lt;workspace&gt;/kb/v&lt;N&gt;/</b> (cards, page index) · <b>fe/_library/{{ gearId }}/deps/v&lt;N&gt;/</b> (dependency graph)</div>
            </ng-container>
            <div>DB: <b>kb_version = _library-re-v&lt;N&gt;</b> (card builds, one per build; approval makes one ACTIVE)</div>
            <div>DB: <b>kb_version = _library-{{ gearId }}-deps-v&lt;N&gt;</b> (dependency graph, rebuilt on upload and on build; current = ACTIVE)</div>
          </div>
        </div>
        <div class="apm-card-body" [hidden]="statusCollapsed" style="padding-top:0;" *ngIf="versions && (versions.cards.items.length || versions.dependency_graph.items.length)">
          <p class="sub" style="margin-bottom:6px;">KB versions in the database:</p>
          <table class="apm-table" style="font-size:12px;">
            <thead><tr><th>Series</th><th>Version</th><th>State</th><th>Built</th><th>Nodes</th><th>Edges</th></tr></thead>
            <tbody>
              <tr *ngFor="let v of newestFirst(versions.cards.items)">
                <td>Card library</td><td style="font-family:monospace">{{ v.kb_version }}</td>
                <td><span class="apm-chip" [class.ok]="v.status === 'ACTIVE'" [class.amber]="v.status === 'STAGING'">{{ v.status === 'ACTIVE' ? 'active' : (v.status || '').toLowerCase() }}</span></td>
                <td>{{ v.built_at | date:'medium' }}</td><td>{{ v.pages }}</td><td>{{ v.edges }}</td>
              </tr>
              <tr *ngFor="let v of newestFirst(versions.dependency_graph.items)">
                <td>Dependency graph</td><td style="font-family:monospace">{{ v.kb_version }}</td>
                <td><span class="apm-chip" [class.ok]="v.is_current" [class.amber]="!v.is_current && v.status === 'STAGING'">{{ v.is_current ? 'current' : (v.status || '').toLowerCase() }}</span></td>
                <td>{{ v.built_at | date:'medium' }}</td><td>{{ v.pages }}</td><td>{{ v.edges }}</td>
              </tr>
            </tbody>
          </table>
          <p class="apm-field-hint" *ngIf="!versions.cards.items.length">No card-library build has been published to the database yet.</p>
        </div>
        <div class="apm-card-body" [hidden]="statusCollapsed" style="padding-top:0;" *ngIf="status.corpus.modules.length">
          <p class="sub" style="margin-bottom:6px;">Modules loaded:</p>
          <div *ngFor="let m of status.corpus.modules"
               style="font-size:12px;padding:4px 8px;background:var(--surface-2,#f5f5f5);border-radius:6px;margin-bottom:4px;">
            <b>{{ m.module_key }}</b>
            <span *ngIf="m.module" style="color:var(--text-secondary);margin-left:6px;">{{ m.module }}</span>
            <span *ngIf="m.app" style="color:var(--text-secondary);margin-left:6px;">· {{ m.app }}</span>
            <span *ngIf="m.stored_at" style="font-family:monospace;font-size:11px;color:var(--text-secondary);margin-left:6px;" [title]="'uploaded ' + (m.uploaded_at || '')">· {{ m.stored_at }}</span>
            <span *ngIf="!m.stored_at" style="font-size:11px;color:#b45309;margin-left:6px;">· on this host only (not in the store yet)</span>
          </div>
        </div>
        <div [hidden]="statusCollapsed" style="border-top:1px solid var(--border,#e5e7eb);margin-top:12px;padding-top:12px;padding-left:16px;padding-right:16px;padding-bottom:16px;">
          <h5 style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--text-secondary);margin:0 0 12px;">Dependency Graph</h5>
          <app-apm-library-dependency-graph [gearId]="gearId" [reloadKey]="graphReload"></app-apm-library-dependency-graph>
        </div>
      </div>

    </ng-container>

    <!-- Placeholder when no Gear ID selected -->
    <div *ngIf="!gearId" class="apm-card">
      <div class="apm-card-body" style="text-align:center;padding:32px;color:var(--text-secondary);">
        Select a Gear ID above to view or upload the library for that application.
      </div>
    </div>
  `,
})
export class GlobalLibraryComponent implements OnInit {
  gearId = "";
  status: LibraryStatus | null = null;
  jsonResult: LibraryDocumentResult | null = null;
  screensResult: LibraryDocumentResult | null = null;

  jsonFile$: File | null = null;
  jsonFileName = "";
  screens$: File | null = null;
  screensFileName = "";
  /** Bumped after a module upload so the dependency-graph card reloads its versions and graph. */
  graphReload = 0;
  /** KB versions behind this Gear ID (card builds + dependency-graph uploads), from GET /library/versions. */
  versions: LibraryVersions | null = null;

  busy = false;
  busyJson = false;
  busyScreens = false;
  busyBuild = false;
  approving = false;

  notice = "";
  error = "";
  buildNotice = "";
  approveError = "";
  statusCollapsed = true;

  jsonViolations: string[] = [];
  jsonViolationMessage = "";
  autoFixing = false;
  autoFixChanges: string[] = [];

  constructor(private readonly svc: AidlcPlatformMgmtService) {}

  ngOnInit(): void {}

  onGearChange(): void {
    this.status = null;
    this.jsonResult = null;
    this.screensResult = null;
    this.notice = "";
    this.error = "";
    this.buildNotice = "";
    if (this.gearId) this.loadStatus();
  }

  loadStatus(): void {
    this.svc.getLibrary(this.gearId).subscribe(s => { this.status = s; });
    this.svc.libraryVersions(this.gearId).subscribe(v => { this.versions = v; });
  }

  /** Newest first, for the version lists in the status card. */
  newestFirst<T>(items: T[] | undefined): T[] { return (items ?? []).slice().reverse(); }

  pickJson(event: Event): void {
    this.jsonFile$ = (event.target as HTMLInputElement).files?.[0] ?? null;
    this.jsonFileName = this.jsonFile$?.name ?? "";
    this.jsonResult = null;
  }

  pickScreens(event: Event): void {
    this.screens$ = (event.target as HTMLInputElement).files?.[0] ?? null;
    this.screensFileName = this.screens$?.name ?? "";
    this.screensResult = null;
  }

  uploadJson(): void {
    if (!this.jsonFile$) return;
    this.jsonViolations = [];
    this.jsonViolationMessage = "";
    this.autoFixChanges = [];
    this.error = "";
    this._doUpload(this.jsonFile$);
  }

  private _doUpload(file: File): void {
    this.busyJson = true;
    this.busy = true;
    this.svc.uploadLibraryDocument(file, "re-cards", this.gearId).subscribe({
      next: (r: any) => {
        this.busyJson = false;
        this.busy = false;
        if (!r) {
          this.error = "Upload failed. Check that the JSON matches the RED format and try again.";
          return;
        }
        if (r._error) {
          this.jsonViolationMessage = r._message ?? "Validation failed";
          this.jsonViolations = r._violations ?? [];
          return;
        }
        this.jsonResult = r as LibraryDocumentResult;
        const s = r.storage;
        this.notice = `Module "${r.module_key}" uploaded for Gear ID "${this.gearId}"` +
          (s && s.ok !== false ? ` and stored in ${this.storeLabel(s.store)}.` : ".") +
          " Build the library to publish the cards and the dependency graph to the database.";
        this.loadStatus();
      },
      error: () => {
        this.busyJson = false;
        this.busy = false;
        this.error = "Upload failed. Check the JSON format and try again.";
      },
    });
  }

  autoFixAndReupload(): void {
    if (!this.jsonFile$) return;
    this.autoFixing = true;

    // Parse violations — two distinct conflict patterns need different treatment
    const conflictingIds = new Set<string>();               // "defined differently" → rename ALL occurrences
    const duplicateIdFirstPage = new Map<string, string>(); // "duplicate id" → keep first-seen page, rename rest

    for (const v of this.jsonViolations) {
      // "duplicate id 'SCR-UWCR-061' in pages[CreditReqDetail.asp].cards.SCR (first seen in pages[comeout.asp].cards.SCR)"
      const mDup = /duplicate id '([^']+)' in pages\[([^\]]+)\].*first seen in pages\[([^\]]+)\]/.exec(v);
      if (mDup) duplicateIdFirstPage.set(mDup[1], mDup[3]);
      // Legacy: "card id '...' is defined differently"
      const mDiff = /card id '([^']+)' is defined differently/.exec(v);
      if (mDiff) conflictingIds.add(mDiff[1]);
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target!.result as string);
        const { fixed, changes } = this._applyAutoFix(data, conflictingIds, duplicateIdFirstPage);
        this.autoFixChanges = changes;
        const blob = new Blob([JSON.stringify(fixed, null, 2)], { type: "application/json" });
        const fixedFile = new File([blob], this.jsonFile$!.name, { type: "application/json" });
        this.autoFixing = false;
        this.jsonViolations = [];
        this.jsonViolationMessage = "";
        this._doUpload(fixedFile);
      } catch {
        this.autoFixing = false;
        this.error = "Auto-fix failed: could not parse the JSON file.";
      }
    };
    reader.readAsText(this.jsonFile$);
  }

  private _applyAutoFix(
    data: any,
    conflictingIds: Set<string> = new Set(),
    duplicateIdFirstPage: Map<string, string> = new Map()
  ): { fixed: any; changes: string[] } {
    const changes: string[] = [];
    const files: any[] = data.files ?? [];
    const ALL_LISTS = ['data_entities', 'business_rules', 'functional_requirements', 'screens', 'workflows', 'services_and_apis', 'components'];

    // Scan all entry types to track max number per ID prefix (e.g. "WF-UWCR-" → 5)
    const maxByPrefix = new Map<string, number>();
    for (const file of files) {
      for (const listKey of ALL_LISTS) {
        for (const entry of (file[listKey] ?? [])) {
          const eid: string = String(entry.id ?? "").trim();
          const m = eid.match(/^([A-Z]+-[A-Z0-9]+-?)(\d+)$/);
          if (m) {
            const num = parseInt(m[2], 10);
            maxByPrefix.set(m[1], Math.max(maxByPrefix.get(m[1]) ?? 0, num));
          }
        }
      }
    }

    // Allocate the next available ID for a given prefix
    const nextId = (prefix: string): string => {
      const next = (maxByPrefix.get(prefix) ?? 0) + 1;
      maxByPrefix.set(prefix, next);
      return `${prefix}${String(next).padStart(3, "0")}`;
    };

    const fixed = JSON.parse(JSON.stringify(data));

    // --- Fix 1: Entity table mapping conflicts (majority table wins) ---
    const entTableCounts = new Map<string, Map<string, number>>();
    for (const file of fixed.files ?? []) {
      for (const ent of (file.data_entities ?? [])) {
        const id: string = String(ent.id ?? "").trim();
        const table: string = String(ent.maps_to_table ?? "").trim();
        if (!id || !table) continue;
        if (!entTableCounts.has(id)) entTableCounts.set(id, new Map());
        const tc = entTableCounts.get(id)!;
        tc.set(table, (tc.get(table) ?? 0) + 1);
      }
    }

    const canonicalTable = new Map<string, string>();
    for (const [id, tableMap] of entTableCounts) {
      let best = "", bestCount = 0;
      for (const [table, count] of tableMap) {
        if (count > bestCount) { best = table; bestCount = count; }
      }
      canonicalTable.set(id, best);
    }

    const reassigned = new Map<string, string>(); // "origId::table" → newId
    for (const file of fixed.files ?? []) {
      for (const ent of (file.data_entities ?? [])) {
        const id: string = String(ent.id ?? "").trim();
        const table: string = String(ent.maps_to_table ?? "").trim();
        if (!id || !table) continue;
        const canonical = canonicalTable.get(id);
        if (!canonical || canonical === table) continue;
        const key = `${id}::${table}`;
        if (!reassigned.has(key)) {
          const m = id.match(/^([A-Z]+-[A-Z0-9]+-?)(\d+)$/);
          reassigned.set(key, nextId(m ? m[1] : `${id.replace(/-?\d+$/, "")}-`));
        }
        const newId = reassigned.get(key)!;
        changes.push(`${file.file_name}: ${id} → ${newId} (table: ${table})`);
        ent.id = newId;
      }
    }

    // --- Fix 2a: Cross-module card ID conflicts (defined differently — rename ALL occurrences) ---
    if (conflictingIds.size > 0) {
      const idRemap = new Map<string, string>();
      conflictingIds.forEach(cid => {
        const m = /^([A-Z]+-[A-Z0-9]+-?)(\d+)$/.exec(cid);
        if (m) idRemap.set(cid, nextId(m[1]));
      });
      for (const file of fixed.files ?? []) {
        const fname: string = String(file.file_name ?? "?");
        for (const listKey of ALL_LISTS) {
          for (const entry of (file[listKey] ?? [])) {
            const eid: string = String(entry.id ?? "").trim();
            if (idRemap.has(eid)) {
              const newId = idRemap.get(eid);
              changes.push(`${fname}: ${eid} → ${newId} (cross-module conflict)`);
              entry.id = newId;
            }
          }
        }
      }
    }

    // --- Fix 2b: Duplicate card IDs across pages — keep first-seen, rename all other occurrences ---
    if (duplicateIdFirstPage.size > 0) {
      for (const file of fixed.files ?? []) {
        const fname: string = String(file.file_name ?? "?");
        for (const listKey of ALL_LISTS) {
          for (const entry of (file[listKey] ?? [])) {
            const eid: string = String(entry.id ?? "").trim();
            if (!duplicateIdFirstPage.has(eid)) continue;
            const firstPage = duplicateIdFirstPage.get(eid)!;
            if (fname.toLowerCase() === firstPage.toLowerCase()) continue; // keep the original
            const m = /^([A-Z]+-[A-Z0-9]+-?)(\d+)$/.exec(eid);
            const prefix = m ? m[1] : `${eid.replace(/-?\d+$/, '')}-`;
            const newId = nextId(prefix);
            changes.push(`${fname}: ${eid} → ${newId} (duplicate id, original kept in ${firstPage})`);
            entry.id = newId;
          }
        }
      }
    }

    return { fixed, changes };
  }

  copyViolations(): void {
    const text = [this.jsonViolationMessage, ...this.jsonViolations].join("\n");
    navigator.clipboard.writeText(text).catch(() => {});
  }

  downloadViolations(): void {
    const text = ["Validation violations", "=".repeat(40), this.jsonViolationMessage, "", ...this.jsonViolations].join("\n");
    const blob = new Blob([text], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "violations-report.txt";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  uploadScreens(): void {
    if (!this.screens$) return;
    this.busyScreens = true;
    this.busy = true;
    this.error = "";
    this.svc.uploadLibraryDocument(this.screens$, "screens", this.gearId).subscribe({
      next: (r) => {
        this.busyScreens = false;
        this.busy = false;
        if (r) {
          this.screensResult = r;
          this.notice = `Screens uploaded for Gear ID "${this.gearId}". ${r.images_bound ?? 0} screenshots bound.`;
          this.loadStatus();
        } else {
          this.error = "Screens upload failed.";
        }
      },
      error: () => {
        this.busyScreens = false;
        this.busy = false;
        this.error = "Screens upload failed.";
      },
    });
  }

  build(): void {
    this.busyBuild = true;
    this.buildNotice = "";
    this.error = "";
    this.svc.buildLibrary(this.gearId).subscribe({
      next: (r) => {
        this.busyBuild = false;
        if (r) {
          const sync = r.inputs_sync;
          const dg = r.dependency_graph;
          const syncText = !sync ? "" :
            sync.ok === false ? ` Input sync from the store failed: ${sync.error || "unknown error"}.` :
            ` Inputs synced from ${this.storeLabel(sync.store)}` +
              (sync.downloaded?.length ? ` (${sync.downloaded.length} file(s) downloaded).` : " (already up to date).");
          const graphText = !dg ? "" :
            dg.ok === false ? ` Dependency graph not rebuilt: ${dg.error || "unknown error"}.` :
            dg.skipped ? ` Dependency graph v${dg.version} kept (inputs unchanged).` :
            ` Dependency graph v${dg.version} rebuilt (${dg.pages} pages, ${dg.edges} references) and made current.`;
          this.buildNotice = `Build started for Gear ID "${this.gearId}".${syncText}${graphText}` +
            ` An "Approve build" button will appear below once the build reaches 'waiting for approval'—refresh the status to check.`;
          this.graphReload++;
          this.loadStatus();
        } else {
          this.error = "Build failed to start. Ensure at least one module is uploaded and no build is already running.";
        }
      },
      error: () => {
        this.busyBuild = false;
        this.error = "Build failed to start.";
      },
    });
  }

  hasCorpus(): boolean {
    return (this.status?.corpus.modules.length ?? 0) > 0;
  }

  isPendingApproval(): boolean {
    const state = (this.status?.latest_build?.state ?? "").toLowerCase();
    return state === 'waiting_for_approval' || state === 'waitingforapproval';
  }

  approveLatestBuild(): void {
    const runId = this.status?.latest_build?.run_id;
    if (!runId) return;
    this.approving = true;
    this.approveError = "";
    this.svc.approve(runId, 'dev@local', 'analyst', 'approve').subscribe({
      next: () => {
        this.approving = false;
        this.notice = `Library build ${runId} approved. Projects can now use this library version.`;
        this.buildNotice = "";
        this.loadStatus();
      },
      error: (e: any) => {
        this.approving = false;
        this.approveError = e?.error?.detail ?? e?.message ?? 'Approval failed — check the pipeline run state.';
      },
    });
  }

  /** "S3" for the bucket, "local store" for FE_ARTIFACT_STORE=local (dev machines). */
  storeLabel(store?: string | null): string {
    return store === "s3" ? "S3" : store === "local" ? "local store" : "store";
  }

  cardKinds(cards: Record<string, number>): string[] {
    return Object.keys(cards);
  }
}
